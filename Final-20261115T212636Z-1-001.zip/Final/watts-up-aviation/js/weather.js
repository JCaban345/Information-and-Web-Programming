/*
  Watt's Up Aviation - Ramp Weather

  What this file does, in order
  1. Figures out where the visitor is.
     First it asks the browser for their exact location (a permission popup).
     If they say no, or the browser can't tell, it estimates the city from
     their internet connection (IP address) using ipapi.co.
     If that also fails, it falls back to White Plains (KHPN), our home base.
  2. Asks Open-Meteo for the current weather at that spot.
     Open-Meteo is a free weather API that doesn't need a key.
  3. Fills in the weather card in the Ramp Weather section.

  Units are the ones the flight line uses. Temperature in F, wind in knots,
  visibility in statute miles (SM).
*/

// Home base, used only if every other way of finding the location fails.
const HOME_BASE = { lat: 41.067, lon: -73.708, name: "White Plains, NY (KHPN)" };

// The degree symbol, written as a code so this file stays plain ASCII.
const DEG = "\u00B0";

// Turns Open-Meteo's weather code (a number) into words and an icon.
// The codes come from the World Meteorological Organization (WMO).
function describeWeather(code, isDay) {
  if (code === 0) return { text: "Clear", icon: isDay ? "icon-sun" : "icon-moon" };
  if (code === 1) return { text: "Mostly clear", icon: isDay ? "icon-sun" : "icon-moon" };
  if (code === 2) return { text: "Partly cloudy", icon: "icon-partly" };
  if (code === 3) return { text: "Overcast", icon: "icon-cloud" };
  if (code === 45 || code === 48) return { text: "Fog", icon: "icon-fog" };
  if (code >= 51 && code <= 57) return { text: "Drizzle", icon: "icon-rain" };
  if (code >= 61 && code <= 67) return { text: "Rain", icon: "icon-rain" };
  if (code >= 71 && code <= 77) return { text: "Snow", icon: "icon-snow" };
  if (code >= 80 && code <= 82) return { text: "Rain showers", icon: "icon-rain" };
  if (code === 85 || code === 86) return { text: "Snow showers", icon: "icon-snow" };
  if (code >= 95) return { text: "Thunderstorms", icon: "icon-storm" };
  return { text: "Unknown", icon: "icon-cloud" };
}

// Wind direction comes in degrees (0 to 360). Pilots read it as a 3-digit number,
// so 90 becomes "090". padStart adds the zeros in front.
function windText(speed, direction) {
  if (Math.round(speed) === 0) return "Calm";
  const dir = String(Math.round(direction / 10) * 10 % 360 || 360).padStart(3, "0");
  return dir + DEG + " at " + Math.round(speed) + " kt";
}

// Visibility comes in meters. One statute mile is 1609 meters.
// Anything over 10 miles is just shown as "10+ SM", like a weather report would.
function visibilityText(meters) {
  const miles = meters / 1609.34;
  if (miles >= 10) return "10+ SM";
  return miles.toFixed(1) + " SM";
}

// A short note about working outside, based on the conditions.
function rampNote(code, gust) {
  if (code >= 95) return "Lightning in the area. Ramp work pauses until it clears.";
  if (gust >= 35) return "Strong gusts. Expect delays on any work outside the hangar.";
  if (code >= 71 && code <= 86) return "Snow on the ramp. We'll plan for hangar space if we can.";
  return "";
}

// Shortcut so we don't have to type document.getElementById every time.
function el(id) {
  return document.getElementById(id);
}

// Step 1a. Ask the browser for the exact location.
// This is wrapped in a Promise so the rest of the code can "await" it.
// If the visitor says no, or it takes longer than 8 seconds, it gives up.
function getBrowserLocation() {
  return new Promise(function (resolve, reject) {
    if (!navigator.geolocation) {
      reject(new Error("No geolocation"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      function (pos) {
        resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude });
      },
      reject,
      { timeout: 8000, maximumAge: 600000 }
    );
  });
}

// Step 1b. Turn the exact coordinates into a city name, like "Teaneck, NJ".
// BigDataCloud has a free lookup for this that doesn't need a key.
async function getCityName(lat, lon) {
  try {
    const url = "https://api.bigdatacloud.net/data/reverse-geocode-client"
      + "?latitude=" + lat + "&longitude=" + lon + "&localityLanguage=en";
    const res = await fetch(url);
    const data = await res.json();
    const city = data.city || data.locality || "Your location";
    // principalSubdivisionCode looks like "US-NJ", so keep only the part after the dash.
    const state = (data.principalSubdivisionCode || "").split("-")[1];
    return state ? city + ", " + state : city;
  } catch (err) {
    return "Your location";
  }
}

// Step 1c. If the browser location didn't work, estimate it from the IP address.
async function getIpLocation() {
  const res = await fetch("https://ipapi.co/json/");
  if (!res.ok) throw new Error("IP lookup failed");
  const data = await res.json();
  if (!data.latitude) throw new Error("No IP location");
  return {
    lat: data.latitude,
    lon: data.longitude,
    name: data.city + (data.region_code ? ", " + data.region_code : "")
  };
}

// Step 1. Try each way of finding the location, in order, until one works.
async function findLocation() {
  try {
    const spot = await getBrowserLocation();
    spot.name = await getCityName(spot.lat, spot.lon);
    spot.source = "Using your device's location";
    return spot;
  } catch (err) {
    // Permission denied or not available. Move on to the IP estimate.
  }

  try {
    const spot = await getIpLocation();
    spot.source = "Approximate location from your internet connection";
    return spot;
  } catch (err) {
    // IP lookup failed too. Use home base.
  }

  return {
    lat: HOME_BASE.lat,
    lon: HOME_BASE.lon,
    name: HOME_BASE.name,
    source: "Couldn't find your location, so this is our home base"
  };
}

// Step 2. Ask Open-Meteo for the weather at that spot.
async function getWeather(lat, lon) {
  const url = "https://api.open-meteo.com/v1/forecast"
    + "?latitude=" + lat + "&longitude=" + lon
    + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,"
    + "weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility"
    + "&daily=temperature_2m_max,temperature_2m_min"
    + "&temperature_unit=fahrenheit&wind_speed_unit=kn"
    + "&timezone=auto&forecast_days=1";
  const res = await fetch(url);
  if (!res.ok) throw new Error("Weather request failed with status " + res.status);
  return res.json();
}

// Step 3. Put everything on the page.
function showWeather(spot, data) {
  const now = data.current;
  const today = data.daily;
  const sky = describeWeather(now.weather_code, now.is_day === 1);

  el("wx-place").textContent = spot.name;
  el("wx-source").textContent = spot.source;
  el("wx-icon").className = "wx-icon " + sky.icon;
  el("wx-temp").textContent = Math.round(now.temperature_2m) + DEG + "F";
  el("wx-cond").textContent = sky.text;
  el("wx-feels").textContent = Math.round(now.apparent_temperature) + DEG + "F";
  el("wx-hilo").textContent = Math.round(today.temperature_2m_max[0]) + DEG + " / "
    + Math.round(today.temperature_2m_min[0]) + DEG;
  el("wx-wind").textContent = windText(now.wind_speed_10m, now.wind_direction_10m);
  el("wx-gust").textContent = Math.round(now.wind_gusts_10m) + " kt";
  el("wx-vis").textContent = visibilityText(now.visibility);
  el("wx-hum").textContent = Math.round(now.relative_humidity_2m) + "%";
  el("wx-note").textContent = rampNote(now.weather_code, now.wind_gusts_10m);

  // Show the time the weather was checked, like "Updated 8:45 AM".
  el("wx-updated").textContent = "Updated " + new Date().toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  });
}

// Run all three steps. If anything breaks, show a message instead of a blank card.
async function loadRampWeather() {
  try {
    const spot = await findLocation();
    el("wx-place").textContent = spot.name;
    const data = await getWeather(spot.lat, spot.lon);
    showWeather(spot, data);
  } catch (err) {
    el("wx-cond").textContent = "Weather is unavailable right now. Try refreshing the page.";
  }
}

loadRampWeather();
